package com.example.frameextracter

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class VideoFramesFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: FrameAdapter
    private val frames = mutableListOf<Bitmap>()

    private val videoPickerLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { extractFramesFromVideo(it) }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_video_frames, container, false)

        val selectButton = view.findViewById<Button>(R.id.btn_select_video)
        recyclerView = view.findViewById(R.id.recyclerView_frames)

        adapter = FrameAdapter(frames)
        recyclerView.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        recyclerView.adapter = adapter

        selectButton.setOnClickListener {
            videoPickerLauncher.launch("video/*")
        }

        return view
    }

    private fun extractFramesFromVideo(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(requireContext(), uri)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0
            val interval = 1000000L  // 1 second

            frames.clear()
            var time = 0L
            while (time < duration * 1000) {
                retriever.getFrameAtTime(time, MediaMetadataRetriever.OPTION_CLOSEST)?.let {
                    frames.add(it)
                }
                time += interval
            }
            retriever.release()

            withContext(Dispatchers.Main) {
                adapter.notifyDataSetChanged()
            }
        }
    }
}
